const esbuild = require('esbuild');

esbuild.build({
  entryPoints: ['./src/app.ts'],
  bundle: true,
  platform: 'node', // Indicates you're targeting Node.js
  target: 'node14', // Target a specific Node.js version
  outfile: './dist/index.js', // Output file after bundling
  external: ['express'], // Exclude dependencies like express from bundling
  minify: true, // Optional: to minify for production
  sourcemap: true, // Optional: for debugging with sourcemaps
}).catch(() => process.exit(1));
