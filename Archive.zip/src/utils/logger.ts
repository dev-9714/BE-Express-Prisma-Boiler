import util from 'util';

export const LOG_LEVELS = {
  info: 'INFO',
  warn: 'WARN',
  error: 'ERROR',
  debug: 'DEBUG',
};

// Helper function to get current ISO timestamp
const getTimestamp = () => new Date().toISOString();

// Helper function to apply colors to the logs (optional)
const applyColor = (level: string, message: string) => {
  const colorMap: { [key: string]: string } = {
    INFO: '\x1b[36m',   // Cyan
    WARN: '\x1b[33m',   // Yellow
    ERROR: '\x1b[31m',  // Red
    DEBUG: '\x1b[35m',  // Magenta
  };
  const resetColor = '\x1b[0m';
  return `${colorMap[level] || ''}${message}${resetColor}`;
};

// Logger function to format and log messages
const log = (level: string, message: string | object, meta?: object) => {
  const timestamp = getTimestamp();
  const metaString = meta ? util.inspect(meta, { colors: true, depth: null }) : ''; // For printing objects nicely
  const logMessage = `[${timestamp}] [${level}] ${message} ${metaString}`;

  // Use different console methods based on log level
  switch (level) {
    case LOG_LEVELS.error:
      console.error(applyColor(level, logMessage));
      break;
    case LOG_LEVELS.warn:
      console.warn(applyColor(level, logMessage));
      break;
    case LOG_LEVELS.debug:
      console.debug(applyColor(level, logMessage));
      break;
    default:
      console.log(applyColor(level, logMessage));
      break;
  }
};

// Logger object with methods for different levels
export const logger = {
  info: (message: string | object, meta?: object) => log(LOG_LEVELS.info, message, meta),
  warn: (message: string | object, meta?: object) => log(LOG_LEVELS.warn, message, meta),
  error: (message: string | object, meta?: object) => log(LOG_LEVELS.error, message, meta),
  debug: (message: string | object, meta?: object) => log(LOG_LEVELS.debug, message, meta),
};
