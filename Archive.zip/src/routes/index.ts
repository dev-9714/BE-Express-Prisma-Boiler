import { Router } from 'express';
import { userRouter } from './userRoutes';

const router = Router();

// userRoutes
router.use('/user',userRouter);

export default router;
