import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

// Middleware for logging requests and responses
export const loggerMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const start = Date.now();
    logger.info({
        method: req.method,
        url: req.url,
        ip: req.ip,
        headers: req.headers,
    });

    res.on('finish', () => {
        const responseTime = Date.now() - start;
        if (res.statusCode >= 400) {
            logger.error({
                statusCode: res.statusCode,
                responseTime: `${responseTime}ms`,
                method: req.method,
                url: req.url,
                ip: req.ip,
            });
        } else {
            logger.info(`Overall response time ${responseTime}ms`);
        }
    });
    next();
};
