import prisma from '../config/database';

const getAllUsers = async () => {
  return await prisma.user.findMany();
};

export default { getAllUsers };
